import { motion } from "framer-motion";

const teamMembers = [
  {
    name: "I Komang Gopal Davinsi",
    role: "Chief Executive Officer (CEO)",
    major: "Teknik Industri",
    image: "https://www.instagram.com/reel/DMwQGIfTtO9/?utm_source=ig_web_button_share_sheet&igsh=MWlkd3M4d3RnaHhjYw==",
  },
  {
    name: "Muhammad Rifqi",
    role: "Chief Technology Officer (CTO)",
    major: "Teknik Industri",
    image: "https://i.ibb.co/gj3FWgm/team3.jpg",
  },
  {
    name: "Umi Muthoharoh",
    role: "Chief Financial Officer (CFO)",
    major: "Akuntansi",
    image: "https://i.ibb.co/1LqCczT/team5.jpg",
  },
  {
    name: "Kavina Nitiakevala Akbari",
    role: "Chief Product Officer (CPO)",
    major: "Farmasi",
    image: "https://ibb.co.com/qLkTSTNJ",
  },
  {
    name: "Lidya Rahmadhani",
    role: "Chief Marketing Officer (CMO)",
    major: "Teknologi Industri Pertanian",
    image: "https://i.ibb.co/qN3pM7H/team2.jpg",
  },
];

export default function Team() {
  return (
    <section className="bg-[#f7f5ef] py-20 px-8 text-center relative overflow-hidden">
      {/* Background daun dekoratif */}
      <div className="absolute inset-0 bg-[url('https://i.ibb.co/qYNsG09/leaves-bg.png')] bg-cover bg-center opacity-5"></div>

      <div className="relative z-10 max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl font-['Playfair_Display'] font-semibold text-[#2f3d2c] mb-12"
        >
          Tim Kami
        </motion.h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-10 justify-center">
          {teamMembers.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.15, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden"
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-5">
                <h3 className="font-semibold text-lg text-[#1e2a1c]">{member.name}</h3>
                <p className="text-sm text-[#436244] font-medium mt-1">{member.role}</p>
                <p className="text-sm text-gray-600 italic mt-1">{member.major}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

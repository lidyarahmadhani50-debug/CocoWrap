import { ShopNowButton } from "./ShopNowButton";

export function Hero() {
  return (
    <section className="relative h-[85vh] flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/10"
        style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, hsl(var(--primary) / 0.1) 0%, transparent 50%),
                           radial-gradient(circle at 80% 80%, hsl(var(--accent) / 0.15) 0%, transparent 50%)`
        }}
      />
      
      <div className="container mx-auto max-w-7xl px-6 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="font-serif text-5xl md:text-7xl font-bold text-foreground mb-6 leading-tight">
            Embrace Nature's
            <span className="text-primary"> Simplicity</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
            Discover eco-friendly alternatives that care for you and our planet. 
            Sustainable, natural, and crafted with love.
          </p>
          <ShopNowButton />
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}

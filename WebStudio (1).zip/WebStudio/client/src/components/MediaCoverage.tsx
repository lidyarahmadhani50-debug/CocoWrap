"use client";

import { motion } from "framer-motion";
import { Globe, Newspaper } from "lucide-react";

export function MediaCoverage() {
  return (
    <section className="bg-[#f9fbf9] py-20 px-6 text-center text-[#2f3d2c]">
      {/* Judul */}
      <motion.h2
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-3xl font-['Playfair_Display'] font-bold mb-8"
      >
        Publikasi Tentang CocoWrap
      </motion.h2>

      {/* Deskripsi singkat */}
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.8 }}
        className="max-w-2xl mx-auto text-lg leading-relaxed mb-12 text-[#3f4a3b]"
      >
        Inovasi CocoWrap telah diliput di berbagai media nasional. Kami bangga
        bisa memperkenalkan solusi kemasan ramah lingkungan yang lahir dari ide
        mahasiswa UGM untuk mengatasi masalah sampah plastik di Indonesia.
      </motion.p>

      {/* Kartu media */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {/* Geotimes */}
        <motion.a
          href="https://geotimes.id/opini/cocowrap-inovasi-pkm-k-ugm-untuk-atasi-sampah-plastik/?snax_post_submission=success"
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.03 }}
          className="border border-[#cbd5cb] rounded-2xl p-6 text-left bg-white shadow-md hover:shadow-lg transition-all"
        >
          <div className="flex items-center gap-3 mb-4">
            <Globe className="h-6 w-6 text-green-700" />
            <h3 className="font-semibold text-lg">Geotimes Indonesia</h3>
          </div>
          <p className="text-sm text-[#3f4a3b] mb-3 font-medium">
            “CocoWrap: Inovasi PKM-K UGM untuk Atasi Sampah Plastik”
          </p>
          <p className="text-xs text-[#6b7369]">Baca selengkapnya →</p>
        </motion.a>

        {/* Kompasiana */}
        <motion.a
          href="https://www.kompasiana.com/lidyarahmadhani/68d508f8ed64151731553634/tim-pkm-k-ugm-kembangkan-cocowrap-kemasan-ramah-lingkungan-dari-sabut-kelapa?l=c"
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.03 }}
          className="border border-[#cbd5cb] rounded-2xl p-6 text-left bg-white shadow-md hover:shadow-lg transition-all"
        >
          <div className="flex items-center gap-3 mb-4">
            <Newspaper className="h-6 w-6 text-green-700" />
            <h3 className="font-semibold text-lg">Kompasiana</h3>
          </div>
          <p className="text-sm text-[#3f4a3b] mb-3 font-medium">
            “Tim PKM-K UGM Kembangkan CocoWrap, Kemasan Ramah Lingkungan dari Sabut Kelapa”
          </p>
          <p className="text-xs text-[#6b7369]">Baca selengkapnya →</p>
        </motion.a>
      </div>
    </section>
  );
}

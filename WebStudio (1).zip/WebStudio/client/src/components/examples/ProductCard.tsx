import { ProductCard } from '../ProductCard';

export default function ProductCardExample() {
  return (
    <div className="p-6 max-w-sm">
      <ProductCard 
        name="Coconut Bowl Set" 
        description="Handcrafted bowls from natural coconut shells"
        category="Kitchen"
      />
    </div>
  );
}

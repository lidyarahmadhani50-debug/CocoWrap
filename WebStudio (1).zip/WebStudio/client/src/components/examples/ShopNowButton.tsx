import { ShopNowButton } from '../ShopNowButton';

export default function ShopNowButtonExample() {
  return <ShopNowButton />;
}

import { Navbar } from '../Navbar';
import { Router } from "wouter";

export default function NavbarExample() {
  return (
    <Router>
      <Navbar />
    </Router>
  );
}

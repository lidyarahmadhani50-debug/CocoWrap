import { ValueCard } from '../ValueCard';
import { Leaf } from 'lucide-react';

export default function ValueCardExample() {
  return (
    <div className="p-6 max-w-sm">
      <ValueCard 
        icon={Leaf}
        title="Sustainable" 
        description="Made from natural, renewable resources that protect our environment"
      />
    </div>
  );
}

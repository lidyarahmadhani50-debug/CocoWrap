import { ScrollAnimation } from '../ScrollAnimation';
import { Card, CardContent } from '@/components/ui/card';

export default function ScrollAnimationExample() {
  return (
    <div className="p-6 space-y-12 min-h-screen">
      <ScrollAnimation>
        <Card>
          <CardContent className="p-6">
            <h3 className="font-semibold mb-2">First Item</h3>
            <p className="text-muted-foreground">This fades in when scrolled into view</p>
          </CardContent>
        </Card>
      </ScrollAnimation>
      
      <ScrollAnimation delay={200}>
        <Card>
          <CardContent className="p-6">
            <h3 className="font-semibold mb-2">Second Item</h3>
            <p className="text-muted-foreground">This fades in with a delay</p>
          </CardContent>
        </Card>
      </ScrollAnimation>
    </div>
  );
}

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Leaf } from "lucide-react";

interface ProductCardProps {
  name: string;
  description: string;
  category: string;
  image?: string;
}

export function ProductCard({ name, description, category }: ProductCardProps) {
  return (
    <Card className="overflow-hidden hover-elevate transition-all duration-300 group">
      <div className="aspect-[4/5] bg-gradient-to-br from-primary/5 to-accent/10 relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <Leaf className="h-20 w-20 text-primary/20 group-hover:scale-110 transition-transform duration-300" />
        </div>
        <Badge className="absolute top-4 right-4" variant="secondary">
          {category}
        </Badge>
      </div>
      <CardContent className="p-6">
        <h3 className="font-semibold text-lg mb-2" data-testid={`text-product-name-${name.toLowerCase().replace(/\s/g, "-")}`}>{name}</h3>
        <p className="text-muted-foreground text-sm">{description}</p>
      </CardContent>
    </Card>
  );
}

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ShoppingBag } from "lucide-react";

export function ShopNowButton() {
  const platforms = [
    {
      name: "Shopee",
      url: "https://shopee.com",
      color: "text-orange-600",
    },
    {
      name: "Tokopedia",
      url: "https://tokopedia.com",
      color: "text-green-600",
    },
    {
      name: "TikTok Shop",
      url: "https://shop.tiktok.com",
      color: "text-black dark:text-white",
    },
  ];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button data-testid="button-shop-now" className="gap-2">
          <ShoppingBag className="h-4 w-4" />
          Shop Now
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        {platforms.map((platform) => (
          <DropdownMenuItem key={platform.name} asChild>
            <a
              href={platform.url}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full cursor-pointer"
              data-testid={`link-platform-${platform.name.toLowerCase().replace(/\s/g, "-")}`}
            >
              <span className={`font-medium ${platform.color}`}>{platform.name}</span>
            </a>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

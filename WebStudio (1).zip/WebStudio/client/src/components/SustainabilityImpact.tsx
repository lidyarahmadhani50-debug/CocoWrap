import { motion } from "framer-motion";
import { Leaf, Recycle, Factory, RefreshCw } from "lucide-react";

export default function SustainabilityImpact() {
  const impacts = [
    {
      icon: <Recycle className="w-8 h-8 text-green-700" />,
      title: "Menggantikan hingga 120 kg plastik per tahun",
    },
    {
      icon: <Leaf className="w-8 h-8 text-green-700" />,
      title: "100% biodegradable & compostable dalam ±3 bulan",
    },
    {
      icon: <Factory className="w-8 h-8 text-green-700" />,
      title: "Sabut kelapa hasil olahan UMKM lokal Jogja",
    },
    {
      icon: <RefreshCw className="w-8 h-8 text-green-700" />,
      title: "Berbasis circular economy: dari limbah menjadi nilai",
    },
  ];

  return (
    <section className="bg-[#F8F4EC] py-20 px-6 md:px-16 text-gray-800 overflow-hidden">
      <motion.div
        className="max-w-5xl mx-auto text-center"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
      >
        <h2 className="text-4xl font-semibold text-green-900 mb-3">
          Sustainability Impact
        </h2>
        <p className="text-lg text-green-700 mb-10">
          Setiap lembar CocoWrap adalah langkah kecil untuk bumi.
        </p>
        <p className="max-w-3xl mx-auto text-gray-700 leading-relaxed mb-16">
          CocoWrap hadir sebagai solusi nyata untuk kemasan ramah lingkungan.
          Terbuat dari limbah sabut kelapa yang diolah kembali oleh UMKM lokal
          di Yogyakarta, setiap produk CocoWrap membantu mengurangi
          ketergantungan terhadap plastik sekali pakai. Kami percaya bahwa
          keberlanjutan bukan hanya tentang bahan alami, tetapi tentang sistem
          yang kembali pada alam tanpa meninggalkan jejak.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-16">
          {impacts.map((impact, index) => (
            <motion.div
              key={index}
              className="bg-white rounded-2xl shadow-md p-8 flex items-start gap-4"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
            >
              {impact.icon}
              <p className="text-left font-medium text-gray-800">{impact.title}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-semibold text-green-900 mb-4">
            Circular Economy
          </h3>
          <p className="max-w-3xl mx-auto text-gray-700 leading-relaxed">
            CocoWrap tumbuh dari prinsip circular economy—setiap bahan yang
            digunakan berasal dari limbah, diolah menjadi produk bernilai guna,
            dan akhirnya dapat kembali ke alam tanpa residu. Dengan sistem ini,
            CocoWrap tidak hanya menghadirkan kemasan yang fungsional, tetapi
            juga berkontribusi dalam menjaga keseimbangan lingkungan dan
            memberdayakan masyarakat lokal.
          </p>
        </motion.div>
      </motion.div>
    </section>
  );
}
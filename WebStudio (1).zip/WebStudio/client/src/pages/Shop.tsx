import { motion } from "framer-motion";

export default function Shop() {
  const shops = [
    {
      name: "Shopee",
      url: "https://id.shp.ee/42exvWA",
      color: "bg-orange-500",
    },
    {
      name: "Tokopedia",
      url: "https://vt.tokopedia.com/t/ZSH7NcYKSCbrF-BT2ob/",
      color: "bg-green-500",
    },
    {
      name: "TikTok Shop",
      url: "https://vt.tokopedia.com/t/ZSH7NcYKSCbrF-BT2ob/",
      color: "bg-black",
    },
  ];

  return (
    <div className="min-h-screen bg-[#f5f9f6] text-center py-20">
      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-4xl font-['Playfair_Display'] font-bold mb-10"
      >
        Belanja CocoWrap
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.8 }}
        className="max-w-xl mx-auto mb-10"
      >
        Kamu bisa mendapatkan produk CocoWrap di berbagai platform online shop berikut 🌿
      </motion.p>

      <div className="flex flex-col md:flex-row justify-center items-center gap-6">
        {shops.map((shop, i) => (
          <motion.a
            key={i}
            href={shop.url}
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 * i }}
            className={`${shop.color} text-white px-8 py-3 rounded-2xl shadow-md hover:opacity-90 transition`}
          >
            {shop.name}
          </motion.a>
        ))}
      </div>
    </div>
  );
}
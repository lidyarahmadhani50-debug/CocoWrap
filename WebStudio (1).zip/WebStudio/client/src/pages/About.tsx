import { motion } from "framer-motion";
import Team from "@/components/Team";
import SustainabilityImpact from "@/components/SustainabilityImpact";
import { MediaCoverage } from "@/components/MediaCoverage"; // pastikan nama import sama persis dengan export-nya

export default function About() {
  return (
    <div className="bg-[#f5f9f6] text-[#2f3d2c] py-20 px-8 text-center">
      {/* Judul utama */}
      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-4xl font-['Playfair_Display'] font-bold mb-6"
      >
        Tentang CocoWrap
      </motion.h1>

      {/* Deskripsi utama */}
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.8 }}
        className="max-w-2xl mx-auto text-lg leading-relaxed"
      >
        CocoWrap lahir dari ide sederhana untuk mengubah limbah sabut kelapa
        menjadi sesuatu yang bermanfaat. Kami percaya bahwa inovasi berkelanjutan
        bisa dimulai dari bahan alami yang sering dianggap tidak bernilai.
        <br /><br />
        Visi kami adalah menciptakan masa depan di mana kemasan tidak hanya
        melindungi produk, tapi juga menjaga bumi.
      </motion.p>

      {/* 🌱 Section Sustainability Impact */}
      <div className="mt-24">
        <SustainabilityImpact />
      </div>

      {/* 👥 Bagian Tim */}
      <div className="mt-24">
        <Team />
      </div>

      {/* 📰 Publikasi / Media Coverage */}
      <div className="mt-24">
        <MediaCoverage />
      </div>
    </div>
  );
}

import { motion } from "framer-motion";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="bg-[#f5f9f6] text-[#2f3d2c] font-['Inter']">
      <section className="flex flex-col items-center justify-center text-center py-20 px-6">
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-6xl font-['Playfair_Display'] font-bold mb-6"
        >
          🌿 CocoWrap
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="max-w-2xl text-lg md:text-xl mb-8"
        >
          Solusi ramah lingkungan untuk kemasan masa depan. Dibuat dari serat
          kelapa alami — kuat, biodegradable, dan sustainable.
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <Link href="/shop">
            <button className="bg-[#3b7a57] hover:bg-[#2f6045] text-white px-8 py-3 rounded-2xl shadow-md transition-all duration-300">
              Belanja Sekarang
            </button>
          </Link>
        </motion.div>
      </section>

      <section className="grid md:grid-cols-3 gap-6 px-8 pb-20">
        {[
          { title: "🌴 Bahan Alami", desc: "Dari serat kelapa murni yang ramah lingkungan." },
          { title: "♻️ Daur Ulang", desc: "100% biodegradable dan mudah terurai di alam." },
          { title: "💡 Inovatif", desc: "Desain fungsional untuk menggantikan plastik konvensional." },
        ].map((item, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 * i }}
            className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all"
          >
            <h3 className="font-['Playfair_Display'] text-xl mb-2 font-semibold">
              {item.title}
            </h3>
            <p>{item.desc}</p>
          </motion.div>
        ))}
      </section>
    </div>
  );
}

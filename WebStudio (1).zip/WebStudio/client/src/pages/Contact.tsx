import { ScrollAnimation } from "@/components/ScrollAnimation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, MapPin, Phone, Instagram, Facebook, Youtube } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Pesan terkirim!",
      description: "Terima kasih sudah menghubungi CocoWrap 💚 Kami akan membalas secepatnya.",
    });
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div className="min-h-screen py-16 bg-[#FAF7F0]">
      <div className="container mx-auto max-w-7xl px-6">
        <ScrollAnimation>
          <div className="text-center mb-12">
            <h1 className="font-serif text-5xl font-bold mb-4 text-[#5C4033]">Hubungi Kami 🌿</h1>
            <p className="text-[#4B3F36] text-lg max-w-2xl mx-auto">
              Ada pertanyaan, saran, atau ingin berkolaborasi?  
              Tim CocoWrap dengan senang hati akan mendengarnya 💌
            </p>
          </div>
        </ScrollAnimation>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-16">
          {/* Form */}
          <ScrollAnimation delay={100}>
            <Card>
              <CardContent className="p-8">
                <h2 className="font-serif text-2xl font-bold mb-6 text-[#5C4033]">Kirim Pesan</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-2 text-[#4B3F36]">
                      Nama
                    </label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Nama lengkap kamu"
                      required
                      data-testid="input-contact-name"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2 text-[#4B3F36]">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="emailmu@email.com"
                      required
                      data-testid="input-contact-email"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium mb-2 text-[#4B3F36]">
                      Pesan
                    </label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Tulis pesanmu di sini..."
                      rows={5}
                      required
                      data-testid="input-contact-message"
                    />
                  </div>
                  <Button type="submit" className="w-full bg-[#5C4033] hover:bg-[#4B3F36]" data-testid="button-submit-contact">
                    Kirim Pesan
                  </Button>
                </form>
              </CardContent>
            </Card>
          </ScrollAnimation>

          {/* Contact Info */}
          <ScrollAnimation delay={200}>
            <div className="space-y-6">
              <Card className="hover-elevate transition-all">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="h-12 w-12 rounded-full bg-[#E6DCCD] flex items-center justify-center flex-shrink-0">
                    <Mail className="h-6 w-6 text-[#5C4033]" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 text-[#5C4033]">Email</h3>
                    <p className="text-muted-foreground text-sm">cocowrap999@gmail.com</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover-elevate transition-all">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="h-12 w-12 rounded-full bg-[#E6DCCD] flex items-center justify-center flex-shrink-0">
                    <Phone className="h-6 w-6 text-[#5C4033]" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 text-[#5C4033]">Nomor</h3>
                    <p className="text-muted-foreground text-sm">+62 812-3456-7890</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover-elevate transition-all">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="h-12 w-12 rounded-full bg-[#E6DCCD] flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-6 w-6 text-[#5C4033]" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 text-[#5C4033]">Lokasi</h3>
                    <p className="text-muted-foreground text-sm">
                      Fakultas Teknologi Pertanian, Universitas Gadjah Mada  
                      Yogyakarta, Indonesia
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Branding & Socials */}
              <Card className="hover-elevate transition-all bg-gradient-to-br from-[#F1E9E3] to-[#E6DCCD]">
                <CardContent className="p-8">
                  <h3 className="font-serif text-xl font-bold mb-4 text-[#5C4033]">Branding & Identitas 🌱</h3>
                  <p className="text-sm text-[#4B3F36] mb-4">
                    Yuk kenal lebih dekat dengan CocoWrap di berbagai platform kami!
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <a href="https://instagram.com/cocowrap_pkmkugm" target="_blank" className="flex items-center gap-2 text-[#5C4033] hover:underline">
                      <Instagram className="w-5 h-5" /> Instagram
                    </a>
                    <a href="https://tiktok.com/@cocowrap_pkmkugm" target="_blank" className="flex items-center gap-2 text-[#5C4033] hover:underline">
                      <Instagram className="w-5 h-5 rotate-45" /> TikTok
                    </a>
                    <a href="https://youtube.com/@cocowrap_pkmkugm" target="_blank" className="flex items-center gap-2 text-[#5C4033] hover:underline">
                      <Youtube className="w-5 h-5" /> YouTube
                    </a>
                    <a href="https://facebook.com/CocoWrapPKMKUGM" target="_blank" className="flex items-center gap-2 text-[#5C4033] hover:underline">
                      <Facebook className="w-5 h-5" /> Facebook
                    </a>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-[#F1E9E3] to-[#E6DCCD] border-none">
                <CardContent className="p-8">
                  <h3 className="font-serif text-xl font-bold mb-2 text-[#5C4033]">Jam Operasional</h3>
                  <div className="space-y-1 text-[#4B3F36] text-sm">
                    <p>Senin – Jumat: 09.00 – 17.00</p>
                    <p>Sabtu: 10.00 – 15.00</p>
                    <p>Minggu: Tutup</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </ScrollAnimation>
        </div>
      </div>
    </div>
  );
}

# CocoWrap Eco-Aesthetic Design Guidelines

## Design Approach

**Strategy:** Reference-Based (Sustainable E-commerce)
Drawing inspiration from eco-conscious brands like Patagonia, Allbirds, and The Honest Company, combined with modern e-commerce patterns from Shopify-powered sustainable stores. The design emphasizes natural aesthetics, organic textures, and earthy minimalism to reinforce CocoWrap's eco-friendly values.

## Core Design Elements

### A. Color Palette

**Light Mode (Primary):**
- Primary Green: 140 35% 45% (Forest green for CTAs and accents)
- Secondary Sage: 120 15% 65% (Soft sage for backgrounds and cards)
- Cream Base: 40 25% 95% (Warm off-white background)
- Earth Brown: 25 40% 35% (Text and grounding elements)
- Accent Terracotta: 15 60% 60% (Subtle highlights)

**Dark Mode:**
- Deep Forest: 140 25% 15% (Background)
- Soft Moss: 120 20% 75% (Text)
- Warm Cream: 40 20% 85% (Secondary text)

### B. Typography

**Font Families:**
- Headings: 'Playfair Display' (serif) - elegant, natural sophistication
- Body: 'Inter' (sans-serif) - clean, modern readability
- Accents: 'Cormorant Garamond' (serif) - organic, artisanal feel

**Type Scale:**
- Hero Headline: 3.5rem (56px) / 4.5rem desktop
- Section Headers: 2.5rem (40px)
- Product Titles: 1.5rem (24px)
- Body Text: 1rem (16px)
- Small Text: 0.875rem (14px)

**Weights:** Regular (400), Medium (500), Semibold (600), Bold (700)

### C. Layout System

**Spacing Primitives:** Tailwind units of 4, 6, 8, 12, 16, 20, 24
- Consistent vertical rhythm using py-16 to py-24 for sections
- Component spacing: p-6 to p-8
- Card gaps: gap-6 to gap-8

**Grid System:**
- Container: max-w-7xl with px-6
- Product grids: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Content sections: max-w-4xl for readability

### D. Component Library

**Navigation:**
- Fixed header with subtle backdrop blur (backdrop-blur-md)
- Logo left, navigation center, "Shop Now" CTA right
- Mobile: Hamburger menu with slide-in drawer
- Sticky on scroll with soft shadow

**Hero Section:**
- Full-width hero with organic lifestyle product photography
- Overlay gradient (from transparent to cream-tinted)
- Large serif headline with handwritten-style accent
- Primary CTA: "Shop Now" dropdown revealing Shopee, Tokopedia, TikTok Shop links
- Height: 85vh with centered content

**Product Cards:**
- Rounded corners (rounded-2xl)
- Soft shadow on hover (transition-shadow)
- Product image with 4:5 aspect ratio
- Product name, brief description, "View Product" link
- Subtle hover lift effect (transform translate-y)

**Shop Now Multi-Platform Button:**
- Primary button triggers dropdown/modal
- Three platform options with recognizable brand colors
- Icons for each platform (use Font Awesome)
- Clean, card-style layout in dropdown

**Contact Form:**
- Single column, generous spacing
- Soft input borders with focus states (ring-2)
- Submit button in primary green
- Two-column layout on desktop: form left, info right

**Footer:**
- Three columns: About snippet, Quick Links, Contact Info
- Social media icons
- Newsletter signup with inline form
- Copyright and eco-certification badges

### E. Animation & Interactions

**Scroll Animations:**
- Fade-in from bottom (translate-y-8 opacity-0 to translate-y-0 opacity-100)
- Staggered timing for card grids (delay-100, delay-200, delay-300)
- Subtle scale on images (0.95 to 1)
- Duration: 600-800ms with ease-out timing

**Micro-interactions:**
- Button hover: slight scale (1.02) and shadow increase
- Card hover: lift effect with shadow enhancement
- Link underlines: expand from left on hover
- Image zoom on product card hover (scale-105)

**Transition Properties:**
- Default: transition-all duration-300 ease-in-out
- Animations trigger at 60% viewport threshold

## Page-Specific Layouts

**Homepage:**
1. Hero with CocoWrap products in natural setting
2. Value proposition (3-column: Sustainable, Eco-friendly, Natural)
3. Featured products grid (4 products)
4. About snippet with founder/story image
5. Testimonials carousel
6. Platform CTA section with Shop Now button

**Shop Page:**
1. Category filter bar (horizontal scroll on mobile)
2. Product grid (9-12 products)
3. Each product links to platform shops
4. Sustainability badge on products

**About Page:**
1. Story hero with team/workspace image
2. Mission statement (full-width)
3. Values grid (4 columns: Sustainable, Natural, Ethical, Quality)
4. Process timeline with images
5. Team section with circular portraits

**Contact Page:**
1. Two-column: Form + Map/Info
2. Office hours, social media, email
3. FAQ accordion below form

## Images

**Required Images:**
- **Homepage Hero:** Large lifestyle shot of CocoWrap products in natural setting (kitchen, eco-friendly home). High-quality, warm lighting. Size: 1920x1080px minimum
- **About Hero:** Workspace or founder story image with warm, authentic feel
- **Product Images:** Clean white background or lifestyle context, 4:5 ratio (800x1000px)
- **Value Props:** Icon-style illustrations or photos of natural materials, sustainability
- **Process/Timeline:** Step-by-step photos showing eco-production
- **Testimonial Avatars:** Circular customer photos (200x200px)

**Image Treatment:**
- Soft rounded corners (rounded-xl to rounded-2xl)
- Subtle grayscale filter with color on hover for product cards
- Organic, warm color grading throughout
- Natural lighting preferred over studio shots

## Accessibility & Responsiveness

- WCAG AA contrast ratios maintained
- Touch targets minimum 44x44px
- Keyboard navigation support
- Responsive breakpoints: sm (640px), md (768px), lg (1024px), xl (1280px)
- Mobile-first approach with stacked layouts

This eco-aesthetic design creates a warm, trustworthy, and modern experience that reflects CocoWrap's sustainable values while providing seamless e-commerce functionality across multiple platforms.